UPDATE InspectionOperations
SET UpdateDateTime = GETDATE()
WHERE MachineName = 'InspectionMachine1';