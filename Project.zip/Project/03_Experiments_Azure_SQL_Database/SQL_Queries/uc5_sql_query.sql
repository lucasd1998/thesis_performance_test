SELECT 
    AVG(CAST(ir.MeasuredValue AS FLOAT)) AS AverageMeasuredValue
FROM 
    InspectionOperations io
JOIN 
    Inspections i ON io.InspectionOperationID = i.InspectionOperationID
JOIN 
    InspectionResults ir ON i.InspectionID = ir.InspectionID
JOIN 
    InspectionsToSetpoints its ON i.InspectionID = its.InspectionID
JOIN 
    Setpoints isp ON its.SetpointID = isp.SetpointID
JOIN 
    InspectionStep ins ON i.InspectionStepID = ins.InspectionStepID
WHERE 
    io.ArticleName = 'EBike'
    AND ins.InspectionName = 'InspectionStepForEBike20'
    AND isp.SetpointName = 'MachineSetPointGroupForEBike.AnyMachineSetpoint1';
