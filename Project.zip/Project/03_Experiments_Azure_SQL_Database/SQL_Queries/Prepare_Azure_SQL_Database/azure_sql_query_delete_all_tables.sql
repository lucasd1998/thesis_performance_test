-- 1. InspectionResults
DROP TABLE IF EXISTS InspectionResults;

-- 2. InspectionsToSetpoints
DROP TABLE IF EXISTS InspectionsToSetpoints;

-- 3. Inspections
DROP TABLE IF EXISTS Inspections;

-- 4. Setpoints
DROP TABLE IF EXISTS Setpoints;

-- 5. InspectionStep
DROP TABLE IF EXISTS InspectionStep;

-- 6. InspectionOperations
DROP TABLE IF EXISTS InspectionOperations;
