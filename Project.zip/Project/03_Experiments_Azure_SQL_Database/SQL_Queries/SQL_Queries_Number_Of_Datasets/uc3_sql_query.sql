SELECT COUNT(DISTINCT io.SerialNumber)
FROM InspectionOperations io
WHERE io.ArticleName = 'Mountainbike' AND io.MachineName = 'InspectionMachine1';