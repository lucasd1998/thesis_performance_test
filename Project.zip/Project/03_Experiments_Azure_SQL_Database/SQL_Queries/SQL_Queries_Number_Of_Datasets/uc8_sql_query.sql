SELECT COUNT(DISTINCT SerialNumber)
FROM InspectionOperations
WHERE MachineName = 'InspectionMachine1';