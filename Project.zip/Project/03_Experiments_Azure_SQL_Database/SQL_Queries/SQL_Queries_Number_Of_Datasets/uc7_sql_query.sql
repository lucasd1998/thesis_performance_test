SELECT COUNT(DISTINCT SerialNumber)
FROM InspectionOperations
WHERE ArticleName = 'Roadbike';