UPDATE InspectionOperations
SET UpdateDateTime = GETDATE()
WHERE SerialNumber = 'SERIALNUMBER';
