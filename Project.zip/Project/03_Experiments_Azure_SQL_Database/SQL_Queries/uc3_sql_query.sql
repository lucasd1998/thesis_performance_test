SELECT 
    *
FROM 
    InspectionOperations io
JOIN 
    Inspections i ON io.InspectionOperationID = i.InspectionOperationID
JOIN 
    InspectionResults ir ON i.InspectionID = ir.InspectionID
JOIN 
    InspectionsToSetpoints its ON i.InspectionID = its.InspectionID
JOIN 
    Setpoints isp ON its.SetpointID = isp.SetpointID
JOIN 
    InspectionStep ins ON i.InspectionStepID = ins.InspectionStepID
WHERE 
    io.ArticleName = 'Mountainbike' AND io.MachineName = 'InspectionMachine1'
