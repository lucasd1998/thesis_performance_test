SELECT * FROM c
WHERE c.ArticleName = 'Mountainbike'
AND c.MachineName = 'InspectionMachine1'