SELECT VALUE AVG(StringToNumber(ir.InspectionResultMeasuredValue))
FROM c
JOIN ir IN c.InspectionsAndResults
WHERE c.ArticleName = 'EBike'
AND ir.InspectionName = 'InspectionStepForEBike20'
AND (ir.InspectionSetpoints["MachineSetPointGroupForEBike.AnyMachineSetpoint1"] != null)