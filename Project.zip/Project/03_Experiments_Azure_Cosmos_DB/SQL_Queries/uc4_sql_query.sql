SELECT * FROM c
WHERE ARRAY_LENGTH(c.InspectionsAndResults) > 0
AND c.MachineName = "InspectionMachine1"
AND EXISTS(
    SELECT VALUE i FROM i IN c.InspectionsAndResults 
    WHERE i.InspectionSetpoints["MachineSetPointGroupForMountainbike.AnyMachineSetpoint1"] != null
    OR i.InspectionSetpoints["MachineSetPointGroupForMountainbike.AnyMachineSetpoint2"] != null
    OR i.InspectionSetpoints["MachineSetPointGroupForMountainbike.AnyMachineSetpoint3"] != null
    OR i.InspectionSetpoints["MachineSetPointGroupForMountainbike.AnyMachineSetpoint4"] != null
    OR i.InspectionSetpoints["MachineSetPointGroupForMountainbike.AnyMachineSetpoint5"] != null
)
