SELECT VALUE COUNT(1) FROM (
    SELECT DISTINCT c.SerialNumber
    FROM c
    JOIN ir IN c.InspectionsAndResults
    WHERE c.ArticleName = 'EBike'
    AND ir.InspectionName = 'InspectionStepForEBike20'
    AND (ir.InspectionSetpoints["MachineSetPointGroupForEBike.AnyMachineSetpoint1"] != null)
) AS NumberOfDistinctSerialNumbers