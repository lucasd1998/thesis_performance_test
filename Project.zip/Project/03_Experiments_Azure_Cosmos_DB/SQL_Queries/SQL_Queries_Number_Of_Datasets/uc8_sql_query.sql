SELECT VALUE COUNT(1)
FROM (
    SELECT DISTINCT c.SerialNumber
    FROM c
    WHERE c.MachineName = 'InspectionMachine1'
) AS NumberOfDistinctSerialNumbers